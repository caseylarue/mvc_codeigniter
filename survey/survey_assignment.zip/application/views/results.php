<html>
<head>
	<title>Results</title>
</head>
<body>
	<div>Tanks for submitting this form! You have submitted this form <?= $counter ?> times now!</div>
	<div>
		<h2>Submitted Information:</h2>
		<p>Name: <?= $name ?></p>
		<p>Language: <?= $location ?></p>
		<p>Location: <?= $language ?></p>
		<p>Comments: <?= $comment ?></p>
	</div>
</body>
</html>